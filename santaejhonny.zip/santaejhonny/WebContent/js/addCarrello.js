var button1=document.getElementById("addcarrello");

button1=onclick=f;

function f() {
	alert("Prodotto aggiunto al carrello");
	
}