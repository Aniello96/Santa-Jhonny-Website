package Beans;


public class Prenotazione {

	private String nomeUtente;
	private int mese;
	private int ora;
	private int n_persone;
	private String descrizione;
	
	public Prenotazione(){
		
	}

	public String getNomeUtente() {
		return nomeUtente;
	}

	public void setNomeUtente(String nomeUtente) {
		this.nomeUtente = nomeUtente;
	}

	public int getMese() {
		return mese;
	}

	public void setMese(int mese) {
		this.mese = mese;
	}

	public int getOra() {
		return ora;
	}

	public void setOra(int ora) {
		this.ora = ora;
	}

	public int getN_persone() {
		return n_persone;
	}

	public void setN_persone(int n_persone) {
		this.n_persone = n_persone;
	}

	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public Prenotazione(String nomeUtente, int mese, int ora, int n_persone, String descrizione) {
		super();
		this.nomeUtente = nomeUtente;
		this.mese = mese;
		this.ora = ora;
		this.n_persone = n_persone;
		this.descrizione = descrizione;
	}

	@Override
	public String toString() {
		return "Prenotazione [nomeUtente=" + nomeUtente + ", mese=" + mese + ", ora=" + ora + ", n_persone=" + n_persone
				+ ", descrizione=" + descrizione + "]";
	}

	
	
	
}
