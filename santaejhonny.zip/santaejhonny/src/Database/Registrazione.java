package Database;

import java.sql.SQLException;

import Beans.Utente;

public class Registrazione {

	public Registrazione(Utente u) throws SQLException{
		DatabaseQuery.addUser(u);
	}
}
