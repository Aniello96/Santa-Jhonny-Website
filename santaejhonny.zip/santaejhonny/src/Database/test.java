package Database;

import java.sql.Date;
import java.sql.SQLException;

import Beans.Prenotazione;
import Beans.Utente;

public class test {

	public static void main(String[] args) throws SQLException {
		/*
		Prenotazione pr = new Prenotazione();
		pr.setNomeUtente("Gigi");
		Date date = new Date(2010,12,30);
		pr.setDate(date);
		pr.setN_persone(3);
		pr.setDescrizione("WEEEE");
		pr.setOra(14);
		DatabaseQuery.addPrenotazione(pr);
		*/
		Utente utente = new Utente("refds", "sfdsf", "fsdfds", "fdsfs", "f", "dsfds");
		System.out.println(DatabaseQuery.addUser(utente));
	}

}
