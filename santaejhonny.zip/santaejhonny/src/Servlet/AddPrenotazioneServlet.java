package Servlet;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Beans.Carrello;
import Beans.Ordine;
import Beans.Prenotazione;
import Beans.Prodotto;
import Beans.Utente;
import Database.DatabaseQuery;

/**
 * Servlet implementation class AddPrenotazioneServlet
 */
@WebServlet("/AddPrenotazioneServlet")
public class AddPrenotazioneServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Prenotazione p = null;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddPrenotazioneServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@SuppressWarnings("unchecked")
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		Utente u = (Utente) session.getAttribute("user");
		
		String email =  u.getEmail();
		
		String persone = request.getParameter("numero_persone");
		int n_persone = Integer.parseInt(persone);
		System.out.println(n_persone);
		
		String Month = request.getParameter("mese"); 
		int mese = Integer.parseInt(Month);
		System.out.print(mese);
		
		String Descrizione = request.getParameter("descrizione");
		System.out.println(Descrizione);
		
		
		try {
			p = DatabaseQuery.getPrenotazione(email);
			if(p==null){
				DatabaseQuery.addPrenotazione(p);
				System.out.println("Inserisco prenotazione " +p.toString());
			}else{
				request.getRequestDispatcher("ErrorePrenotazione.jsp");
				System.out.println("Elemento gi� presente!");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
					
		session.setAttribute("carrello", p);
		
		request.getRequestDispatcher("CarrelloLog.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
